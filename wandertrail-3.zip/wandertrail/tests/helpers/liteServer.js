import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../../server/config.js';
import { createControllers } from '../../server/controllers/index.js';
import { errorHandler, apiNotFound } from '../../server/middleware/index.js';

/**
 * Test-only HTTP adapter. It routes requests to the same controllers and the
 * same error handler the Express app uses, so API behaviour can be tested
 * without installing Express. Express wiring itself is covered in express.test.js.
 */
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json' };

export async function startLiteServer(repo, { serveStatic = false } = {}) {
  const c = createControllers(repo);
  const table = [
    ['GET', /^\/api\/health$/, c.health],
    ['GET', /^\/api\/districts$/, c.listDistricts],
    ['GET', /^\/api\/circuits$/, c.listCircuits],
    ['GET', /^\/api\/sites$/, c.listSites],
    ['GET', /^\/api\/transit$/, c.listTransit],
    ['GET', /^\/api\/sites\/([^/]+)\/transit$/, c.getTransit, 'id'],
    ['GET', /^\/api\/sites\/([^/]+)$/, c.getSite, 'id'],
    ['POST', /^\/api\/itineraries\/plan$/, c.planItinerary],
    ['POST', /^\/api\/itineraries$/, c.createItinerary],
    ['GET', /^\/api\/itineraries\/([^/]+)$/, c.getItinerary, 'id'],
  ];

  const server = http.createServer(async (req, res) => {
    res.status = (code) => { res.statusCode = code; return res; };
    res.json = (body) => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(body)); return res; };
    const url = new URL(req.url, 'http://localhost');
    try {
      if (url.pathname.startsWith('/api/')) {
        const hit = table.find(([m, re]) => m === req.method && re.test(url.pathname));
        if (!hit) return apiNotFound(req, res);
        let body;
        if (req.method === 'POST') {
          const chunks = [];
          for await (const chunk of req) chunks.push(chunk);
          const text = Buffer.concat(chunks).toString('utf8');
          if (text.length > 20_000) { const e = new Error('too large'); e.type = 'entity.too.large'; throw e; }
          try { body = text ? JSON.parse(text) : undefined; } catch { const e = new Error('bad json'); e.type = 'entity.parse.failed'; throw e; }
        }
        const match = url.pathname.match(hit[1]);
        const params = hit[3] ? { [hit[3]]: decodeURIComponent(match[1]) } : {};
        return hit[2]({ query: Object.fromEntries(url.searchParams), params, body }, res);
      }
      if (serveStatic) {
        const rel = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
        const file = path.join(config.publicDir, path.normalize(rel));
        if (!file.startsWith(config.publicDir) || !fs.existsSync(file)) { res.statusCode = 404; return res.end('Not found'); }
        res.setHeader('Content-Type', MIME[path.extname(file)] ?? 'application/octet-stream');
        return res.end(fs.readFileSync(file));
      }
      res.statusCode = 404;
      return res.end();
    } catch (err) {
      return errorHandler(err, req, res, () => {});
    }
  });

  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return { url: `http://127.0.0.1:${port}`, close: () => new Promise((resolve) => server.close(resolve)) };
}
