import test from 'node:test';
import assert from 'node:assert/strict';
import { createRepository } from '../server/db/repository.js';

/**
 * Integration test for the real Express app. It runs after `npm install`
 * and is skipped automatically when Express is not installed.
 */
let createApp = null;
try {
  ({ createApp } = await import('../server/app.js'));
} catch (err) {
  if (err.code !== 'ERR_MODULE_NOT_FOUND') throw err;
}

test('express app: API, headers, static files, rate limit-safe', { skip: !createApp && 'express is not installed' }, async () => {
  const repo = await createRepository({ dbPath: ':memory:' });
  const server = createApp(repo).listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const health = await fetch(`${base}/api/health`);
    assert.equal(health.status, 200);
    assert.equal(health.headers.get('x-content-type-options'), 'nosniff');
    assert.match(health.headers.get('content-security-policy'), /default-src 'self'/);
    assert.equal(health.headers.get('x-powered-by'), null);

    const plan = await fetch(`${base}/api/itineraries/plan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ siteIds: ['ramappa-temple', 'warangal-fort', 'thousand-pillar-temple'] }),
    });
    assert.equal(plan.status, 200);

    const malformed = await fetch(`${base}/api/itineraries/plan`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{oops' });
    assert.equal(malformed.status, 400);

    const big = await fetch(`${base}/api/itineraries/plan`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ siteIds: ['a'], pad: 'x'.repeat(30000) }) });
    assert.equal(big.status, 413);

    const page = await fetch(`${base}/`);
    assert.equal(page.status, 200);
    assert.match(await page.text(), /WanderTrail/);
  } finally {
    await new Promise((r) => server.close(r));
    repo.close();
  }
});
