import test from 'node:test';
import assert from 'node:assert/strict';
import {
  cleanText,
  isSlug,
  validatePlanRequest,
  validateShareId,
  validateSharedItinerary,
  validateSiteQuery,
} from '../server/services/validation.js';
import { HttpError } from '../server/errors.js';

const bad = (fn) => assert.throws(fn, (e) => e instanceof HttpError && e.status === 400);

test('cleanText strips markup characters and control codes and caps length', () => {
  assert.equal(cleanText('  <b>Hi</b>\u0000 there  '), 'bHi/b there');
  assert.equal(cleanText('x'.repeat(200), 10).length, 10);
  assert.equal(cleanText(42), '');
});

test('isSlug accepts ids and rejects traversal and junk', () => {
  assert.ok(isSlug('ramappa-temple'));
  for (const v of ['../etc', 'A', 'a b', '', 'x'.repeat(61), null, 5, "a'; DROP TABLE x;--"]) assert.equal(isSlug(v), false);
});

test('validateSiteQuery accepts known shapes', () => {
  assert.deepEqual(validateSiteQuery({ circuit: 'kakatiya', district: 'warangal', q: ' Fort ' }), {
    circuit: 'kakatiya', district: 'warangal', q: 'fort',
  });
  assert.deepEqual(validateSiteQuery({}), {});
});

test('validateSiteQuery rejects bad filters', () => {
  bad(() => validateSiteQuery({ circuit: 'Bad Value' }));
  bad(() => validateSiteQuery({ district: '../x' }));
  bad(() => validateSiteQuery({ q: ['a', 'b'] }));
});

test('validatePlanRequest applies defaults', () => {
  const r = validatePlanRequest({ siteIds: ['a-b', 'c-d'] });
  assert.equal(r.startTime, '09:00');
  assert.equal(r.optimize, true);
  assert.equal(r.origin, null);
  assert.equal(r.date, undefined);
});

test('validatePlanRequest rejects malformed bodies', () => {
  bad(() => validatePlanRequest(null));
  bad(() => validatePlanRequest([]));
  bad(() => validatePlanRequest({}));
  bad(() => validatePlanRequest({ siteIds: [] }));
  bad(() => validatePlanRequest({ siteIds: 'abc' }));
  bad(() => validatePlanRequest({ siteIds: ['ok', 'Not OK'] }));
  bad(() => validatePlanRequest({ siteIds: ['a', 'a'] }));
  bad(() => validatePlanRequest({ siteIds: Array.from({ length: 13 }, (_, i) => `s${i}`) }));
  bad(() => validatePlanRequest({ siteIds: ['a'], startTime: '9am' }));
  bad(() => validatePlanRequest({ siteIds: ['a'], startTime: '24:00' }));
  bad(() => validatePlanRequest({ siteIds: ['a'], date: '2026-02-31' }));
  bad(() => validatePlanRequest({ siteIds: ['a'], date: 'tomorrow' }));
  bad(() => validatePlanRequest({ siteIds: ['a'], optimize: 'yes' }));
});

test('validatePlanRequest validates origin', () => {
  bad(() => validatePlanRequest({ siteIds: ['a'], origin: { lat: '1', lng: 2 } }));
  bad(() => validatePlanRequest({ siteIds: ['a'], origin: { lat: 91, lng: 0 } }));
  bad(() => validatePlanRequest({ siteIds: ['a'], origin: { lat: 0, lng: 181 } }));
  const ok = validatePlanRequest({ siteIds: ['a'], origin: { name: '<script>x</script>', lat: 17, lng: 78 } });
  assert.equal(ok.origin.name, 'scriptx/script');
});

test('validatePlanRequest accepts a real date', () => {
  assert.equal(validatePlanRequest({ siteIds: ['a'], date: '2026-11-23' }).date, '2026-11-23');
});

test('validateSharedItinerary requires a title and a valid plan', () => {
  bad(() => validateSharedItinerary({ plan: { siteIds: ['a'] } }));
  bad(() => validateSharedItinerary({ title: '   ', plan: { siteIds: ['a'] } }));
  bad(() => validateSharedItinerary({ title: 'T', plan: { siteIds: [] } }));
  const { title, request } = validateSharedItinerary({ title: '  My <trip> ', plan: { siteIds: ['a'] } });
  assert.equal(title, 'My trip');
  assert.deepEqual(request.siteIds, ['a']);
});

test('validateShareId only accepts UUID-shaped ids', () => {
  assert.equal(validateShareId('123e4567-e89b-12d3-a456-426614174000'), '123e4567-e89b-12d3-a456-426614174000');
  bad(() => validateShareId('../../etc/passwd'));
  bad(() => validateShareId(undefined));
});
