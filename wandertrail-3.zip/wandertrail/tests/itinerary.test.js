import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildSchedule,
  chooseStart,
  greedySequence,
  pathLengthKm,
  planItinerary,
  toHHMM,
  toMinutes,
  twoOpt,
} from '../server/services/itinerary.js';

const site = (id, lat, lng, extra = {}) => ({
  id,
  name: id.toUpperCase(),
  district: 'x',
  lat,
  lng,
  visitMinutes: 60,
  hours: { open: '09:00', close: '17:00', closedDays: [] },
  ...extra,
});

// Points along a line running away from Hyderabad: A (near) -> B -> C -> D (far)
const A = site('a', 17.9, 79.0);
const B = site('b', 18.0, 79.2);
const C = site('c', 18.1, 79.4);
const D = site('d', 18.2, 79.6);

test('time helpers round-trip', () => {
  assert.equal(toMinutes('09:30'), 570);
  assert.equal(toHHMM(570), '09:30');
  assert.throws(() => toMinutes('9:30'), TypeError);
  assert.throws(() => toMinutes('25:00'), TypeError);
});

test('greedy sequence follows the line regardless of input order', () => {
  const order = greedySequence([C, A, D, B], A);
  assert.deepEqual(order.map((s) => s.id), ['a', 'b', 'c', 'd']);
});

test('chooseStart begins at the end of the widest pair nearer Hyderabad', () => {
  assert.equal(chooseStart([D, B, A, C]).id, 'a');
});

test('chooseStart with an origin picks the closest site', () => {
  const origin = { lat: 18.25, lng: 79.7 };
  assert.equal(chooseStart([A, B, C, D], origin).id, 'd');
});

test('planItinerary orders a shuffled list into a monotonic route', () => {
  const plan = planItinerary([D, B, A, C]);
  assert.deepEqual(plan.stops.map((s) => s.id), ['a', 'b', 'c', 'd']);
  assert.equal(plan.algorithm, 'greedy-nearest-neighbour+2-opt');
});

test('optimised path is never longer than the input order', () => {
  const input = [C, A, D, B];
  const plan = planItinerary(input);
  const optimised = plan.stops.map((s) => input.find((x) => x.id === s.id));
  assert.ok(pathLengthKm(optimised) <= pathLengthKm(input) + 1e-9);
});

test('2-opt removes a crossing that greedy leaves in place', () => {
  // Greedy from P1 goes P2, P3, P4, which crosses; the optimal open path is P1, P2, P4, P3... check it never gets worse.
  const P1 = site('p1', 17.0, 78.0);
  const P2 = site('p2', 17.0, 78.5);
  const P3 = site('p3', 17.5, 78.0);
  const P4 = site('p4', 17.5, 78.5);
  const greedy = greedySequence([P1, P2, P3, P4], P1);
  const refined = twoOpt(greedy);
  assert.ok(pathLengthKm(refined) <= pathLengthKm(greedy) + 1e-9);
  assert.equal(refined[0].id, 'p1');
});

test('optimize:false keeps the caller order', () => {
  const plan = planItinerary([C, A, B], { optimize: false });
  assert.deepEqual(plan.stops.map((s) => s.id), ['c', 'a', 'b']);
  assert.equal(plan.algorithm, 'user-defined-order');
});

test('single-stop plan has zero distance', () => {
  const plan = planItinerary([A]);
  assert.equal(plan.totalKm, 0);
  assert.equal(plan.stops.length, 1);
});

test('empty input throws', () => {
  assert.throws(() => planItinerary([]), TypeError);
});

test('origin leg is included in the total distance', () => {
  const origin = { name: 'Home', lat: 17.385, lng: 78.4867 };
  const without = planItinerary([A, B]);
  const withOrigin = planItinerary([A, B], { origin });
  assert.ok(withOrigin.totalKm > without.totalKm);
  assert.equal(withOrigin.origin.name, 'Home');
});

test('schedule: times advance by travel plus visit duration', () => {
  const { stops } = buildSchedule([A, B], { startTime: '09:00' });
  assert.equal(stops[0].arrive, '09:00');
  assert.equal(stops[0].depart, '10:00');
  assert.ok(toMinutes(stops[1].arrive) > toMinutes(stops[0].depart));
});

test('schedule: waits for opening time and warns', () => {
  const { stops, warnings } = buildSchedule([A], { startTime: '07:00' });
  assert.equal(stops[0].arrive, '09:00');
  assert.match(warnings[0], /opens at 09:00/);
});

test('schedule: warns when a visit would overrun closing time', () => {
  const late = site('late', 17.9, 79.0, { hours: { open: '09:00', close: '17:00', closedDays: [] } });
  const { warnings } = buildSchedule([late], { startTime: '16:30' });
  assert.ok(warnings.some((w) => /closes at 17:00/.test(w)));
});

test('schedule: warns when the chosen weekday is a closed day', () => {
  const fri = site('fri', 17.9, 79.0, { hours: { open: '09:00', close: '17:00', closedDays: [5] } });
  // 2026-11-20 is a Friday
  const { warnings } = buildSchedule([fri], { startTime: '10:00', date: '2026-11-20' });
  assert.ok(warnings.some((w) => /closed on this weekday/.test(w)));
  const ok = buildSchedule([fri], { startTime: '10:00', date: '2026-11-21' });
  assert.equal(ok.warnings.length, 0);
});

test('schedule: adds a lunch break once the clock passes 12:30', () => {
  const s1 = site('s1', 17.9, 79.0, { visitMinutes: 240 });
  const s2 = site('s2', 17.9, 79.0, { visitMinutes: 30 });
  const { stops } = buildSchedule([s1, s2], { startTime: '09:00' });
  // 09:00 + 240 = 13:00 depart; zero travel; lunch 45 min before s2.
  assert.equal(stops[1].arrive, '13:45');
});

test('deterministic: identical input gives identical output', () => {
  const a = planItinerary([D, A, C, B]);
  const b = planItinerary([D, A, C, B]);
  assert.deepEqual(a, b);
});
