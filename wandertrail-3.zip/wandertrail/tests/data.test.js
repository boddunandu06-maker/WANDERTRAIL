import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../server/config.js';

const load = (f) => JSON.parse(fs.readFileSync(path.join(config.seedDir, f), 'utf8'));
const sites = load('sites.json');
const districts = load('districts.json');
const circuits = load('circuits.json');
const transit = load('transit.json');
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

test('dataset has 25 heritage sites and all 33 districts', () => {
  assert.equal(sites.length, 25);
  assert.equal(districts.length, 33);
});

test('ids are unique slugs', () => {
  for (const list of [sites, districts, circuits]) {
    const ids = list.map((x) => x.id);
    assert.equal(new Set(ids).size, ids.length);
    ids.forEach((id) => assert.match(id, /^[a-z0-9-]+$/));
  }
});

test('every site references a real circuit and district', () => {
  const c = new Set(circuits.map((x) => x.id));
  const d = new Set(districts.map((x) => x.id));
  sites.forEach((s) => {
    assert.ok(c.has(s.circuit), `${s.id}: circuit ${s.circuit}`);
    assert.ok(d.has(s.district), `${s.id}: district ${s.district}`);
  });
});

test('required fields and sane values on every site', () => {
  sites.forEach((s) => {
    for (const f of ['name', 'dynasty', 'period', 'summary', 'history', 'architecture', 'dressCode', 'bestTime']) {
      assert.ok(typeof s[f] === 'string' && s[f].length > 5, `${s.id}.${f}`);
    }
    assert.match(s.hours.open, HHMM);
    assert.match(s.hours.close, HHMM);
    assert.ok(s.hours.open < s.hours.close, `${s.id} hours`);
    assert.ok(s.visitMinutes >= 15 && s.visitMinutes <= 240, `${s.id} visitMinutes`);
    assert.ok(Array.isArray(s.photoSpots) && s.photoSpots.length >= 1);
    // Telangana lies roughly within 15.8-19.95 N, 77.2-81.4 E.
    assert.ok(s.lat > 15.5 && s.lat < 20 && s.lng > 77 && s.lng < 81.5, `${s.id} coordinates`);
  });
});

test('every site has exactly one transit record', () => {
  assert.equal(transit.length, sites.length);
  const ids = new Set(sites.map((s) => s.id));
  transit.forEach((t) => {
    assert.ok(ids.has(t.siteId), t.siteId);
    assert.ok(t.fromHyderabadKm > 0);
  });
});

test('the brief\'s example sites are present', () => {
  const names = sites.map((s) => s.name).join(' | ');
  for (const n of ['Golconda', 'Charminar', 'Ramappa', 'Warangal Fort', 'Bhongir', 'Medak Cathedral', 'Thousand Pillar']) {
    assert.ok(names.includes(n), n);
  }
  assert.ok(sites.find((s) => s.id === 'ramappa-temple').unesco);
});
