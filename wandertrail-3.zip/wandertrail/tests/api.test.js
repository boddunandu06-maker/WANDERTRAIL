import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createRepository } from '../server/db/repository.js';
import { startLiteServer } from './helpers/liteServer.js';

let repo;
let srv;

before(async () => {
  repo = await createRepository({ dbPath: ':memory:' });
  srv = await startLiteServer(repo);
});

after(async () => {
  await srv.close();
  repo.close();
});

const get = (p) => fetch(`${srv.url}${p}`);
const post = (p, body, raw) =>
  fetch(`${srv.url}${p}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: raw ?? JSON.stringify(body) });

test('GET /api/health', async () => {
  const res = await get('/api/health');
  assert.equal(res.status, 200);
  assert.equal((await res.json()).status, 'ok');
});

test('GET /api/sites returns all 25 sites', async () => {
  const body = await (await get('/api/sites')).json();
  assert.equal(body.count, 25);
});

test('GET /api/sites filters by circuit', async () => {
  const body = await (await get('/api/sites?circuit=kakatiya')).json();
  assert.ok(body.count >= 3);
  body.data.forEach((s) => assert.equal(s.circuit, 'kakatiya'));
});

test('GET /api/sites filters by district', async () => {
  const body = await (await get('/api/sites?district=hyderabad')).json();
  assert.ok(body.count >= 5);
  body.data.forEach((s) => assert.equal(s.district, 'hyderabad'));
});

test('GET /api/sites combines circuit and district and text search', async () => {
  const body = await (await get('/api/sites?circuit=kakatiya&district=mulugu&q=ramappa')).json();
  assert.ok(body.data.every((s) => s.district === 'mulugu'));
  assert.ok(body.data.some((s) => s.id === 'ramappa-temple'));
});

test('GET /api/sites rejects an invalid filter with 400', async () => {
  assert.equal((await get('/api/sites?circuit=DROP%20TABLE')).status, 400);
});

test('GET /api/districts lists 33 districts with counts', async () => {
  const body = await (await get('/api/districts')).json();
  assert.equal(body.data.length, 33);
  assert.equal(body.data.reduce((n, d) => n + d.siteCount, 0), 25);
});

test('GET /api/sites/:id includes transit; unknown id is 404; bad id is 400', async () => {
  const ok = await (await get('/api/sites/ramappa-temple')).json();
  assert.equal(ok.data.id, 'ramappa-temple');
  assert.ok(ok.data.transit.fromHyderabadKm > 0);
  assert.equal((await get('/api/sites/nope')).status, 404);
  assert.equal((await get('/api/sites/BAD_ID')).status, 400);
});

test('GET /api/transit lists a route per site', async () => {
  const body = await (await get('/api/transit')).json();
  assert.equal(body.data.length, 25);
});

test('POST /api/itineraries/plan: the brief\'s Warangal demo', async () => {
  const res = await post('/api/itineraries/plan', {
    siteIds: ['thousand-pillar-temple', 'ramappa-temple', 'warangal-fort'],
  });
  assert.equal(res.status, 200);
  const { data } = await res.json();
  assert.equal(data.stops.length, 3);
  assert.ok(data.totalKm > 60 && data.totalKm < 90, `totalKm ${data.totalKm}`);
  // Ramappa is the far end of the trail, so it must be first or last, never in the middle.
  const ids = data.stops.map((s) => s.id);
  assert.notEqual(ids[1], 'ramappa-temple');
  assert.ok(data.stops[0].arrive <= data.stops[2].arrive);
});

test('POST /api/itineraries/plan rejects unknown sites with details', async () => {
  const res = await post('/api/itineraries/plan', { siteIds: ['ramappa-temple', 'does-not-exist'] });
  assert.equal(res.status, 400);
  assert.deepEqual((await res.json()).error.details.missing, ['does-not-exist']);
});

test('POST /api/itineraries/plan rejects malformed JSON and bad input', async () => {
  assert.equal((await post('/api/itineraries/plan', null, '{not json')).status, 400);
  assert.equal((await post('/api/itineraries/plan', {})).status, 400);
  assert.equal((await post('/api/itineraries/plan', { siteIds: ['golconda-fort'], startTime: '99:99' })).status, 400);
});

test('POST /api/itineraries/plan respects optimize:false order', async () => {
  const ids = ['ramappa-temple', 'golconda-fort', 'warangal-fort'];
  const { data } = await (await post('/api/itineraries/plan', { siteIds: ids, optimize: false })).json();
  assert.deepEqual(data.stops.map((s) => s.id), ids);
});

test('share flow: create then fetch an itinerary', async () => {
  const created = await post('/api/itineraries', {
    title: 'Warangal day',
    plan: { siteIds: ['warangal-fort', 'thousand-pillar-temple'], date: '2026-11-23' },
  });
  assert.equal(created.status, 201);
  const { id } = (await created.json()).data;
  const fetched = await (await get(`/api/itineraries/${id}`)).json();
  assert.equal(fetched.data.title, 'Warangal day');
  assert.equal(fetched.data.plan.plan.stops.length, 2);
  assert.equal((await get('/api/itineraries/00000000-0000-0000-0000-000000000000')).status, 404);
  assert.equal((await get('/api/itineraries/not-a-uuid')).status, 400);
});

test('SQL injection strings are inert', async () => {
  const res = await get(`/api/sites?q=${encodeURIComponent("' OR 1=1; DROP TABLE heritage_sites;--")}`);
  assert.equal(res.status, 200);
  assert.equal((await res.json()).count, 0);
  assert.equal((await (await get('/api/sites')).json()).count, 25);
});

test('unknown API route is a JSON 404', async () => {
  const res = await get('/api/nope');
  assert.equal(res.status, 404);
  assert.ok((await res.json()).error);
});
