import test from 'node:test';
import assert from 'node:assert/strict';
import { haversineKm, roadKm } from '../server/services/geo.js';

const charminar = { lat: 17.3616, lng: 78.4747 };
const golconda = { lat: 17.3833, lng: 78.4011 };

test('haversine: distance to self is zero', () => {
  assert.equal(haversineKm(charminar, charminar), 0);
});

test('haversine: is symmetric', () => {
  assert.ok(Math.abs(haversineKm(charminar, golconda) - haversineKm(golconda, charminar)) < 1e-9);
});

test('haversine: Charminar to Golconda is roughly 8 km', () => {
  const d = haversineKm(charminar, golconda);
  assert.ok(d > 7 && d < 9, `got ${d}`);
});

test('haversine: one degree of latitude is about 111 km', () => {
  const d = haversineKm({ lat: 17, lng: 78 }, { lat: 18, lng: 78 });
  assert.ok(Math.abs(d - 111.19) < 0.2, `got ${d}`);
});

test('haversine: rejects invalid points', () => {
  assert.throws(() => haversineKm({ lat: NaN, lng: 1 }, charminar), TypeError);
  assert.throws(() => haversineKm(null, charminar), TypeError);
});

test('roadKm scales straight-line distance by the factor', () => {
  assert.ok(Math.abs(roadKm(charminar, golconda, 2) - 2 * haversineKm(charminar, golconda)) < 1e-9);
});
