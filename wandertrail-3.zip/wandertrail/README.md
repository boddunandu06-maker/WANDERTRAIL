# WanderTrail: Heritage Highway Hack

A heritage tourism web app for Telangana. Browse 25 monuments across five heritage circuits, filter by any of the 33 districts, read visiting guides, and build a day-trip itinerary that is automatically ordered and timed.

## Quick start

Requires **Node.js 22.5 or newer** (uses the built-in `node:sqlite`).

```bash
npm install     # installs Express, the only dependency
npm start       # http://localhost:3000
npm test        # runs the automated tests
```

Set `PORT` or `DB_PATH` to override the defaults. The SQLite file is created and seeded on first start.
If your Node has no `node:sqlite`, the app falls back to a JSON store automatically.

## Demo script (from the brief)

1. Open the home page and click **Try the Warangal demo**, or go to **Explore**, choose the *Kakatiya Circuit* and the *Mulugu* or *Warangal* district.
2. Add Ramappa Temple, Warangal Fort and Thousand Pillar Temple to the itinerary.
3. The builder orders them, shows timings, an estimated road distance (about 71 km) and a route sketch.
4. Click **Download plan (.txt)**, **Print**, **Save to My Trips** or **Create share link**.

## Architecture (three tiers)

```
Browser (vanilla ES modules)  ->  Express REST API  ->  SQLite data tier
public/js/views, lib              server/routes          server/db/repository.js
                                  server/controllers     tables: districts, circuits,
                                  server/services        heritage_sites, transit_routes,
                                  server/middleware      itineraries
```

* **Presentation** (`public/`): small ES modules, one per view, plus shared libraries (`api`, `store`, `dom`, `format`, `audio`). All HTML is produced by an escaping `html` template tag, so data is never injected unescaped.
* **Application** (`server/`): routes call controllers, which validate input and call services. Controllers use only `req.query/params/body` and `res.status().json()`, so they are unit-testable without Express.
* **Data** (`server/db/`): a repository class hides storage. Seed data lives in `server/db/seed/*.json` and is loaded in a single transaction.

## Itinerary algorithm

`server/services/itinerary.js`

1. **Start choice**: with an origin, the nearest site; otherwise the end of the widest pair of selected sites that is nearer Hyderabad, so trips fan outward along the highway.
2. **Greedy nearest-neighbour** sequencing using estimated road distance (Haversine x 1.3). Ties break by id, so output is deterministic.
3. **2-opt refinement** (for four or more stops) removes route crossings while keeping the start fixed.
4. **Scheduling**: adds travel time (45 km/h average), a lunch break after 12:30, waits for opening time, and warns about closing time and closed weekdays.

Distances are estimates, labelled as such in the UI and API.

## API

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Liveness check |
| GET | `/api/districts` | 33 districts with site counts |
| GET | `/api/circuits` | Circuits with site counts |
| GET | `/api/sites?circuit=&district=&q=` | Filtered monument list |
| GET | `/api/sites/:id` | Monument detail including transit |
| GET | `/api/sites/:id/transit` | Transit guide for one site |
| GET | `/api/transit` | Transit guide for all sites |
| POST | `/api/itineraries/plan` | Order and schedule a day trip |
| POST | `/api/itineraries` | Create an unlisted share link |
| GET | `/api/itineraries/:id` | Fetch a shared itinerary |

Plan request body:

```json
{ "siteIds": ["ramappa-temple", "warangal-fort"], "startTime": "09:00",
  "date": "2026-11-23", "optimize": true,
  "origin": { "name": "Hyderabad", "lat": 17.385, "lng": 78.4867 } }
```

## Security and robustness

* Server-side validation of every query and body (types, slugs, ranges, real dates, size limits); unknown ids return 400 with the missing ids.
* Parameterised SQL only; tested with injection strings.
* Escaping template tag on the client; Content-Security-Policy with no inline script or style; `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`.
* Per-IP rate limit, 20 KB body limit, no stack traces in error responses.
* Shared itineraries are unlisted UUIDs; there is no public listing endpoint.
* Data read back from `localStorage` is re-validated before use.

## Tests

`npm test` runs 55+ tests with Node's built-in runner: Haversine maths, sequencing and scheduling, validation, dataset integrity (25 sites, 33 districts, valid references and coordinates), and the HTTP API. `tests/express.test.js` exercises the real Express app (headers, static files, 400/413 handling) and runs after `npm install`.

## Features

Must-have: heritage directory by circuit and dynasty; interactive itinerary builder with add, remove, reorder (buttons or drag), optimise, export; monument detail with hours, tickets, photo spots and dress code; transit guide from Hyderabad; wishlist and saved trips in localStorage; district filter for all 33 districts.

Stretch: audio guide (Web Speech API, narration of about 60 seconds built from each site's data); heritage passport with location-checked check-ins and badges (a clearly labelled demo mode skips the location check); emergency contacts page using national numbers.

Not included: the 360-degree panorama, because it needs licensed panoramic photographs. Cards use generated artwork instead of photos for the same reason; add images under `public/assets` and reference them from the card when you have them.

## Data caveats

Opening hours, ticket prices, transport details and coordinates are indicative, compiled for this project, and some remote-site coordinates are approximate. Verify before travelling and before relying on the data in a submission. Update `server/db/seed/*.json` and delete `data/wandertrail.db` to reseed.
