import { html, mount, toast } from '../lib/dom.js';
import { getCatalog } from '../lib/catalog.js';
import { store } from '../lib/store.js';
import { currentPosition, haversineKm } from '../lib/geo.js';

const CHECKIN_RADIUS_KM = 1.5;
let root = null;
let demoMode = false;

function awards(stamps, sites, circuits) {
  const earned = new Set(Object.keys(stamps));
  const list = [
    { name: 'First Stamp', ok: earned.size >= 1 },
    { name: 'Five Sites', ok: earned.size >= 5 },
    { name: 'UNESCO Explorer', ok: sites.filter((s) => s.unesco).some((s) => earned.has(s.id)) },
  ];
  circuits.forEach((c) => {
    const ids = sites.filter((s) => s.circuit === c.id).map((s) => s.id);
    list.push({ name: `${c.name} Complete`, ok: ids.length > 0 && ids.every((id) => earned.has(id)) });
  });
  return list;
}

function draw() {
  const { sites, circuits } = getCatalog();
  const stamps = store.stamps();
  const got = Object.keys(stamps).filter((id) => sites.some((s) => s.id === id)).length;
  mount(root, html`
    <h1>Heritage passport</h1>
    <p>Check in at a monument to collect its stamp. You must be within ${CHECKIN_RADIUS_KM} km of the site.</p>
    <p><strong>${got} of ${sites.length}</strong> stamps collected.</p>
    <div class="badges" aria-label="Badges">
      ${awards(stamps, sites, circuits).map((a) => html`<span class="award ${a.ok ? '' : 'locked'}">${a.ok ? '★' : '☆'} ${a.name}</span>`)}
    </div>
    <label class="check section"><input type="checkbox" id="demoMode" data-change="demo-toggle" ${demoMode ? 'checked' : ''}> Demo mode: skip the location check (for trying the passport away from the sites)</label>
    <div class="stamp-grid section">
      ${sites.map((s) => html`
        <div class="stamp c-${s.circuit} ${stamps[s.id] ? 'done' : ''}">
          <strong>${s.name}</strong><br>
          ${stamps[s.id]
            ? html`<span class="meta">Stamped ${stamps[s.id].slice(0, 10)}</span>`
            : html`<button class="btn small" data-action="checkin" data-id="${s.id}">Check in</button>`}
        </div>`)}
    </div>`);
}

export const passport = {
  render(el) {
    root = el;
    draw();
  },
  actions: {
    async checkin(el) {
      const site = getCatalog().siteMap.get(el.dataset.id);
      if (!site) return;
      if (!demoMode) {
        el.disabled = true;
        try {
          const pos = await currentPosition();
          const km = haversineKm(pos, site);
          if (km > CHECKIN_RADIUS_KM) {
            el.disabled = false;
            return toast(`You are about ${km.toFixed(1)} km away. Get within ${CHECKIN_RADIUS_KM} km to check in.`);
          }
        } catch (err) {
          el.disabled = false;
          return toast(err.message);
        }
      }
      store.addStamp(site.id);
      toast(`Stamp collected: ${site.name}`);
      return draw();
    },
  },
  changes: {
    'demo-toggle'(el) {
      demoMode = el.checked;
    },
  },
};
