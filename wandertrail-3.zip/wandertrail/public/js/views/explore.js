import { html, mount } from '../lib/dom.js';
import { getCatalog } from '../lib/catalog.js';
import { siteCard } from './siteCard.js';

let filters = { q: '', circuit: '', district: '' };
let root = null;

function applyFilters() {
  const { sites } = getCatalog();
  const q = filters.q.trim().toLowerCase();
  return sites.filter((s) => {
    if (filters.circuit && s.circuit !== filters.circuit) return false;
    if (filters.district && s.district !== filters.district) return false;
    if (q && !`${s.name} ${s.dynasty} ${s.summary}`.toLowerCase().includes(q)) return false;
    return true;
  });
}

function results() {
  const list = applyFilters();
  const out = root.querySelector('#results');
  root.querySelector('#count').textContent = `${list.length} monument${list.length === 1 ? '' : 's'}`;
  mount(out, list.length
    ? html`${list.map(siteCard)}`
    : html`<p class="empty">No monuments match these filters. Try another district or clear the search.</p>`);
  const params = new URLSearchParams(Object.entries(filters).filter(([, v]) => v));
  history.replaceState(null, '', `#/explore${params.size ? `?${params}` : ''}`);
}

function onFilter() {
  filters = {
    q: root.querySelector('#fq').value,
    circuit: root.querySelector('#fc').value,
    district: root.querySelector('#fd').value,
  };
  results();
}

export const explore = {
  render(el, params) {
    root = el;
    filters = {
      q: params.get('q') ?? '',
      circuit: params.get('circuit') ?? '',
      district: params.get('district') ?? '',
    };
    const { circuits, districts, sites } = getCatalog();
    const withSites = new Map();
    sites.forEach((s) => withSites.set(s.district, (withSites.get(s.district) ?? 0) + 1));
    mount(el, html`
      <h1>Heritage directory</h1>
      <form class="filters" role="search">
        <label>Search<input id="fq" type="search" maxlength="60" value="${filters.q}" placeholder="Temple, fort, dynasty…" data-input="filter"></label>
        <label>Circuit
          <select id="fc" data-change="filter">
            <option value="">All circuits</option>
            ${circuits.map((c) => html`<option value="${c.id}" ${c.id === filters.circuit ? 'selected' : ''}>${c.name}</option>`)}
          </select>
        </label>
        <label>District (all 33)
          <select id="fd" data-change="filter">
            <option value="">All districts</option>
            ${districts.map((d) => html`<option value="${d.id}" ${d.id === filters.district ? 'selected' : ''}>${d.name}${withSites.get(d.id) ? ` (${withSites.get(d.id)})` : ''}</option>`)}
          </select>
        </label>
      </form>
      <p class="meta" id="count" aria-live="polite"></p>
      <div class="grid" id="results"></div>`);
    results();
  },

  // Wired by main.js to [data-input] / [data-change] controls.
  inputs: { filter: onFilter },
  changes: { filter: onFilter },
};
