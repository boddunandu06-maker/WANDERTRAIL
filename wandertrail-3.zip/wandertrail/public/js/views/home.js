import { html, mount } from '../lib/dom.js';
import { getCatalog } from '../lib/catalog.js';
import { store } from '../lib/store.js';
import { siteCard } from './siteCard.js';

const DEMO = ['ramappa-temple', 'warangal-fort', 'thousand-pillar-temple'];

export const home = {
  render(root) {
    const { circuits, sites, siteMap } = getCatalog();
    const featured = sites.filter((s) => s.unesco || ['golconda-fort', 'charminar', 'bhongir-fort'].includes(s.id)).slice(0, 3);
    mount(root, html`
      <section class="hero">
        <h1>Discover Telangana's heritage trails</h1>
        <p>Kakatiya temples, Qutb Shahi citadels, Nizam palaces and Buddhist stupas, with visiting hours, tickets, transport from Hyderabad and a smart day-trip planner.</p>
        <div class="btn-row">
          <a class="btn" href="#/explore">Explore ${sites.length} monuments</a>
          <button class="btn secondary" data-action="demo">Try the Warangal demo</button>
        </div>
      </section>

      <section class="section">
        <div class="section-head"><h2>Heritage circuits</h2><a href="#/explore">View all</a></div>
        <div class="grid">
          ${circuits.map((c) => html`
            <a class="circuit-tile c-${c.id}" href="#/explore?circuit=${encodeURIComponent(c.id)}">
              <h3>${c.name}</h3>
              <p>${c.tagline}</p>
              <p class="meta">${c.siteCount} sites · ${c.highway}</p>
            </a>`)}
        </div>
      </section>

      <section class="section">
        <div class="section-head"><h2>Featured monuments</h2></div>
        <div class="grid">${featured.map(siteCard)}</div>
      </section>`);
    return siteMap;
  },

  actions: {
    demo() {
      const draft = store.draft();
      store.saveDraft({ ...draft, siteIds: DEMO, optimize: true, origin: 'none' });
      location.hash = '#/builder';
    },
  },
};
