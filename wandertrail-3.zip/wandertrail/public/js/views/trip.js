import { api } from '../lib/api.js';
import { html, mount } from '../lib/dom.js';
import { store } from '../lib/store.js';
import { renderPlanInto } from './builder.js';

/** Read-only view of a shared itinerary (#/trip/<id>). */
export const trip = {
  async render(el, params, id) {
    mount(el, html`<p class="loading">Loading shared itinerary…</p>`);
    try {
      const { title, plan } = await api.sharedItinerary(id);
      mount(el, html`<h1>${title}</h1><div id="sharedPlan"></div>
        <p><button class="btn" data-action="trip-edit" data-ids="${plan.plan.stops.map((s) => s.id).join(',')}">Open in builder</button></p>`);
      renderPlanInto(el.querySelector('#sharedPlan'), plan.plan, { readOnly: true });
    } catch (err) {
      mount(el, html`<h1>Itinerary not found</h1><p class="notice error">${err.message}</p><p><a href="#/">Back to home</a></p>`);
    }
  },
  actions: {
    'trip-edit'(el) {
      const ids = el.dataset.ids.split(',').filter((s) => /^[a-z0-9-]{1,60}$/.test(s));
      store.saveDraft({ ...store.draft(), siteIds: ids, optimize: false });
      location.hash = '#/builder';
    },
  },
};
