import { api } from '../lib/api.js';
import { html, mount, toast } from '../lib/dom.js';
import { getCatalog } from '../lib/catalog.js';
import { store } from '../lib/store.js';
import { MAX_STOPS } from '../lib/actions.js';
import { currentPosition } from '../lib/geo.js';
import { download, duration, planToText, time12 } from '../lib/format.js';

const HYDERABAD = { name: 'Hyderabad', lat: 17.385, lng: 78.4867 };

let root = null;
let seq = 0;
let timer = null;
let lastPlan = null;
let dragId = null;

const out = () => root.querySelector('#planOut');

/* ---------- rendering ---------- */

function stopList(draft) {
  const { siteMap } = getCatalog();
  if (!draft.siteIds.length) {
    return html`<p class="empty">No stops yet. Add monuments below or from the <a href="#/explore">directory</a>.</p>`;
  }
  return html`<ol class="stop-list" id="stopList">
    ${draft.siteIds.map((id, i) => {
      const s = siteMap.get(id);
      if (!s) return '';
      return html`
      <li class="stop-item c-${s.circuit}" draggable="true" data-id="${s.id}">
        <span class="stop-num">${i + 1}</span>
        <span><strong>${s.name}</strong><br><span class="meta">${duration(s.visitMinutes)} visit</span></span>
        <span class="btn-row">
          <button class="btn small secondary" data-action="b-up" data-id="${s.id}" aria-label="Move ${s.name} earlier" ${i === 0 ? 'disabled' : ''}>↑</button>
          <button class="btn small secondary" data-action="b-down" data-id="${s.id}" aria-label="Move ${s.name} later" ${i === draft.siteIds.length - 1 ? 'disabled' : ''}>↓</button>
          <button class="btn small danger" data-action="b-remove" data-id="${s.id}" aria-label="Remove ${s.name}">✕</button>
        </span>
      </li>`;
    })}
  </ol>`;
}

function addSelect(draft) {
  const { sites, circuits } = getCatalog();
  const chosen = new Set(draft.siteIds);
  return html`
    <label>Add a monument
      <select id="bAdd">
        <option value="">Choose a monument…</option>
        ${circuits.map((c) => {
          const options = sites.filter((s) => s.circuit === c.id && !chosen.has(s.id));
          return options.length ? html`<optgroup label="${c.name}">${options.map((s) => html`<option value="${s.id}">${s.name}</option>`)}</optgroup>` : '';
        })}
      </select>
    </label>
    <button class="btn secondary" data-action="b-add" ${draft.siteIds.length >= MAX_STOPS ? 'disabled' : ''}>Add stop</button>`;
}

function renderLists() {
  const draft = store.draft();
  mount(root.querySelector('#stops'), stopList(draft));
  mount(root.querySelector('#adder'), addSelect(draft));
  const optimise = root.querySelector('#bOptimise');
  if (optimise) optimise.checked = draft.optimize;
}

function routeSvg(plan) {
  const pts = plan.stops;
  const W = 600;
  const H = 220;
  const pad = 28;
  const lats = pts.map((p) => p.lat);
  const lngs = pts.map((p) => p.lng);
  const midLat = (Math.min(...lats) + Math.max(...lats)) / 2;
  const kx = Math.cos((midLat * Math.PI) / 180);
  const spanX = Math.max((Math.max(...lngs) - Math.min(...lngs)) * kx, 0.01);
  const spanY = Math.max(Math.max(...lats) - Math.min(...lats), 0.01);
  const scale = Math.min((W - pad * 2) / spanX, (H - pad * 2) / spanY);
  const cx = (Math.max(...lngs) + Math.min(...lngs)) / 2;
  const cy = (Math.max(...lats) + Math.min(...lats)) / 2;
  const xy = (p) => [W / 2 + (p.lng - cx) * kx * scale, H / 2 - (p.lat - cy) * scale];
  const coords = pts.map(xy);
  const line = coords.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  return html`
    <svg class="route-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Sketch of the route between ${pts.length} stops, north is up">
      ${pts.length > 1 && html`<polyline points="${line}" fill="none" stroke="#9a3f12" stroke-width="3" stroke-dasharray="7 5" stroke-linecap="round"/>`}
      ${coords.map(([x, y], i) => html`
        <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="13" fill="#9a3f12"/>
        <text x="${x.toFixed(1)}" y="${(y + 5).toFixed(1)}" text-anchor="middle" fill="#fff" font-size="14" font-weight="700">${i + 1}</text>`)}
    </svg>`;
}

function planView(plan, { readOnly = false } = {}) {
  const { siteMap } = getCatalog();
  const first = plan.stops[0];
  return html`
    <div class="panel">
      <h2>Your day plan</h2>
      <div class="summary-bar">
        <div><strong>${plan.totalKm} km</strong><span class="meta">est. road distance</span></div>
        <div><strong>${duration(plan.driveMinutes)}</strong><span class="meta">driving</span></div>
        <div><strong>${time12(plan.endTime)}</strong><span class="meta">finish${plan.date ? ` · ${plan.date}` : ''}</span></div>
      </div>
      ${plan.warnings.map((w) => html`<p class="notice">${w}</p>`)}
      ${routeSvg(plan)}
      <ol class="timeline">
        ${plan.origin && html`<li><strong>Start from ${plan.origin.name}</strong></li>`}
        ${plan.stops.map((s) => html`
          <li class="c-${siteMap.get(s.id)?.circuit ?? 'kakatiya'}">
            ${s.legKm > 0 && html`<div class="leg">${s.legKm} km, about ${duration(s.legMinutes)} drive</div>`}
            <strong>${s.order}. ${s.name}</strong><br>
            <span class="meta">${time12(s.arrive)} to ${time12(s.depart)} · ${duration(s.visitMinutes)}</span>
            <button class="btn small secondary" data-action="open" data-id="${s.id}">Details</button>
          </li>`)}
      </ol>
      <p class="meta">${plan.note}</p>
      ${first && !readOnly && html`
        <div class="btn-row">
          <button class="btn" data-action="b-download">Download plan (.txt)</button>
          <button class="btn secondary" data-action="b-print">Print</button>
        </div>
        <hr>
        <label>Trip name<input id="tripTitle" maxlength="80" value="${plan.date ? `Trip on ${plan.date}` : 'My heritage day trip'}"></label>
        <div class="btn-row">
          <button class="btn secondary" data-action="b-save">Save to My Trips</button>
          <button class="btn secondary" data-action="b-share">Create share link</button>
        </div>`}
    </div>`;
}

export function renderPlanInto(el, plan, options) {
  lastPlan = plan;
  mount(el, planView(plan, options));
}

/* ---------- planning ---------- */

async function requestBody(draft) {
  const body = { siteIds: draft.siteIds, startTime: draft.startTime, optimize: draft.optimize };
  if (draft.date) body.date = draft.date;
  if (draft.origin === 'hyderabad') body.origin = HYDERABAD;
  if (draft.origin === 'location') {
    const pos = await currentPosition();
    body.origin = { name: 'Your location', ...pos };
  }
  return body;
}

async function runPlan() {
  const draft = store.draft();
  const mine = ++seq;
  if (!draft.siteIds.length) {
    lastPlan = null;
    mount(out(), html`<div class="panel empty"><h2>Your day plan appears here</h2><p>Add two or more monuments and WanderTrail will order them into a sensible day trip.</p></div>`);
    return;
  }
  mount(out(), html`<p class="loading">Planning your route…</p>`);
  try {
    const plan = await api.plan(await requestBody(draft));
    if (mine !== seq) return; // a newer request superseded this one
    if (draft.optimize) {
      store.saveDraft({ ...draft, siteIds: plan.stops.map((s) => s.id) });
      renderLists();
    }
    renderPlanInto(out(), plan);
  } catch (err) {
    if (mine !== seq) return;
    mount(out(), html`<p class="notice error">${err.message}</p>`);
  }
}

function schedule() {
  clearTimeout(timer);
  timer = setTimeout(runPlan, 250);
}

function update(patch) {
  store.saveDraft({ ...store.draft(), ...patch });
  renderLists();
  schedule();
}

function move(id, delta) {
  const draft = store.draft();
  const ids = draft.siteIds.slice();
  const i = ids.indexOf(id);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= ids.length) return;
  [ids[i], ids[j]] = [ids[j], ids[i]];
  manualOrder(ids);
}

function manualOrder(ids) {
  const wasOptimised = store.draft().optimize;
  update({ siteIds: ids, optimize: false });
  if (wasOptimised) toast('Manual order on. Tick "Optimise order" to re-sequence.');
}

/* ---------- view contract ---------- */

export const builder = {
  render(el) {
    root = el;
    const draft = store.draft();
    mount(el, html`
      <h1>Day-trip itinerary builder</h1>
      <div class="split">
        <section class="panel" aria-label="Trip settings">
          <h2>Your stops</h2>
          <div id="stops"></div>
          <div class="btn-row" id="adder"></div>
          <hr>
          <div class="filters">
            <label>Date (optional)<input id="bDate" type="date" value="${draft.date}" data-change="b-setting"></label>
            <label>Start time<input id="bStart" type="time" value="${draft.startTime}" data-change="b-setting"></label>
            <label>Start from
              <select id="bOrigin" data-change="b-setting">
                <option value="none" ${draft.origin === 'none' ? 'selected' : ''}>First stop</option>
                <option value="hyderabad" ${draft.origin === 'hyderabad' ? 'selected' : ''}>Hyderabad</option>
                <option value="location" ${draft.origin === 'location' ? 'selected' : ''}>My current location</option>
              </select>
            </label>
          </div>
          <label class="check"><input id="bOptimise" type="checkbox" data-change="b-setting" ${draft.optimize ? 'checked' : ''}> Optimise order (nearest-neighbour + 2-opt)</label>
          <div class="btn-row">
            <button class="btn" data-action="b-plan">Build itinerary</button>
            <button class="btn danger" data-action="b-clear">Clear all</button>
          </div>
        </section>
        <section id="planOut" aria-live="polite"></section>
      </div>`);
    renderLists();
    runPlan();
  },

  actions: {
    'b-add'() {
      const select = root.querySelector('#bAdd');
      if (!select.value) return toast('Choose a monument first');
      const draft = store.draft();
      return update({ siteIds: [...draft.siteIds, select.value] });
    },
    'b-remove': (el) => update({ siteIds: store.draft().siteIds.filter((id) => id !== el.dataset.id) }),
    'b-up': (el) => move(el.dataset.id, -1),
    'b-down': (el) => move(el.dataset.id, 1),
    'b-plan': () => { clearTimeout(timer); runPlan(); },
    'b-clear': () => update({ siteIds: [] }),
    'b-download'() {
      if (!lastPlan) return;
      download('wandertrail-itinerary.txt', planToText(lastPlan, root.querySelector('#tripTitle')?.value || 'WanderTrail day trip'));
    },
    'b-print': () => window.print(),
    'b-save'() {
      const draft = store.draft();
      const title = (root.querySelector('#tripTitle')?.value ?? '').trim().slice(0, 80) || 'My heritage day trip';
      store.addTrip({ title, siteIds: draft.siteIds, startTime: draft.startTime, date: draft.date, optimize: false, origin: draft.origin });
      toast('Trip saved to My Trips');
    },
    async 'b-share'() {
      if (!lastPlan) return;
      const title = (root.querySelector('#tripTitle')?.value ?? '').trim().slice(0, 80) || 'My heritage day trip';
      const draft = store.draft();
      try {
        const body = await requestBody({ ...draft, optimize: false, siteIds: lastPlan.stops.map((s) => s.id) });
        const saved = await api.share({ title, plan: body });
        const link = `${location.origin}${location.pathname}#/trip/${saved.id}`;
        try {
          await navigator.clipboard.writeText(link);
          toast('Share link copied');
        } catch {
          toast(link);
        }
      } catch (err) {
        toast(err.message);
      }
    },
  },

  changes: {
    'b-setting'() {
      update({
        date: root.querySelector('#bDate').value,
        startTime: root.querySelector('#bStart').value || '09:00',
        origin: root.querySelector('#bOrigin').value,
        optimize: root.querySelector('#bOptimise').checked,
      });
    },
  },

  drag: {
    start(li) { dragId = li.dataset.id; li.classList.add('dragging'); },
    end(li) { li.classList.remove('dragging'); dragId = null; },
    drop(li) {
      if (!dragId || dragId === li.dataset.id) return;
      const ids = store.draft().siteIds.filter((id) => id !== dragId);
      ids.splice(ids.indexOf(li.dataset.id), 0, dragId);
      manualOrder(ids);
    },
  },
};
