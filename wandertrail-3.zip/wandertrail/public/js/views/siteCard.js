import { html } from '../lib/dom.js';
import { circuitOf, districtName } from '../lib/catalog.js';
import { store } from '../lib/store.js';

const ARCH = html`<svg viewBox="0 0 64 72" aria-hidden="true" focusable="false"><path d="M8 72V34a24 24 0 0 1 48 0v38h-9V35a15 15 0 0 0-30 0v37z" fill="currentColor"/><circle cx="32" cy="6" r="4" fill="currentColor"/></svg>`;

export function siteCard(site) {
  const circuit = circuitOf(site);
  const saved = store.wishlist().includes(site.id);
  const inTrip = store.draft().siteIds.includes(site.id);
  return html`
    <article class="card c-${site.circuit}">
      <div class="card-art">
        ${site.unesco && html`<span class="chip solid unesco">UNESCO World Heritage</span>`}
        <span class="chip solid">${circuit?.name ?? site.circuit}</span>
        ${ARCH}
      </div>
      <div class="card-body">
        <h3>${site.name}</h3>
        <p class="meta">${districtName(site.district)} · ${site.dynasty} · ${site.period}</p>
        <p>${site.summary}</p>
        <div class="card-actions">
          <button class="btn small" data-action="open" data-id="${site.id}">Details</button>
          <button class="btn small secondary" data-action="wish" data-id="${site.id}" aria-pressed="${saved}">${saved ? '♥ Saved' : '♡ Save'}</button>
          <button class="btn small secondary" data-action="add" data-id="${site.id}" ${inTrip ? 'disabled' : ''}>${inTrip ? 'In itinerary' : '+ Itinerary'}</button>
        </div>
      </div>
    </article>`;
}
