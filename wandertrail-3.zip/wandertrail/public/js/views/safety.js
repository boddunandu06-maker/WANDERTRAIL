import { html, mount } from '../lib/dom.js';

/** National numbers that apply across Telangana. Local numbers vary, so none are invented here. */
const CONTACTS = [
  { number: '112', label: 'National emergency number', note: 'Police, fire and ambulance from any phone.' },
  { number: '100', label: 'Police', note: 'Telangana Police control room.' },
  { number: '108', label: 'Ambulance', note: 'Emergency medical response.' },
  { number: '1363', label: 'Tourist helpline', note: 'Ministry of Tourism multilingual tourist helpline.' },
  { number: '181', label: 'Women helpline', note: 'Support for women in distress.' },
  { number: '1098', label: 'Childline', note: 'Support for children in need.' },
];

export const safety = {
  render(el) {
    mount(el, html`
      <h1>Safety and emergency contacts</h1>
      <p>Tap a number to call from your phone.</p>
      <div class="sos-grid">
        ${CONTACTS.map((c) => html`
          <a class="sos" href="tel:${c.number}"><strong>${c.number}</strong>${c.label}<br><span class="meta">${c.note}</span></a>`)}
      </div>
      <section class="section panel">
        <h2>Tips for remote heritage sites</h2>
        <ul>
          <li>Carry water, sun protection and a power bank; phone coverage can be patchy near rural monuments.</li>
          <li>Share your itinerary with someone and travel back before dark on country roads.</li>
          <li>For a licensed guide, ask at the monument ticket counter or contact the Telangana Tourism office.</li>
          <li>For medical help away from a city, call 108 and ask for the nearest government hospital.</li>
        </ul>
      </section>`);
  },
};
