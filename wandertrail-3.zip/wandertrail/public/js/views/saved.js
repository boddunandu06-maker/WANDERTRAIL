import { html, mount, toast } from '../lib/dom.js';
import { getCatalog } from '../lib/catalog.js';
import { store } from '../lib/store.js';
import { siteCard } from './siteCard.js';

let root = null;

function draw() {
  const { siteMap } = getCatalog();
  const wishlist = store.wishlist().map((id) => siteMap.get(id)).filter(Boolean);
  const trips = store.trips();
  mount(root, html`
    <h1>Saved trips and wishlist</h1>
    <p class="meta">Saved on this device in your browser's local storage.</p>

    <section class="section">
      <h2>My trips (${trips.length})</h2>
      ${trips.length ? html`
        <div class="grid two">
          ${trips.map((t) => html`
            <article class="panel">
              <h3>${t.title}</h3>
              <p class="meta">${t.siteIds.length} stop${t.siteIds.length === 1 ? '' : 's'}${t.date ? ` · ${t.date}` : ''}${t.savedAt ? ` · saved ${t.savedAt.slice(0, 10)}` : ''}</p>
              <ol>${t.siteIds.map((id) => html`<li>${siteMap.get(id)?.name ?? id}</li>`)}</ol>
              <div class="btn-row">
                <button class="btn small" data-action="trip-open" data-id="${t.id}">Open in builder</button>
                <button class="btn small danger" data-action="trip-delete" data-id="${t.id}">Delete</button>
              </div>
            </article>`)}
        </div>` : html`<p class="empty">No saved trips yet. Build an itinerary and choose "Save to My Trips".</p>`}
    </section>

    <section class="section">
      <h2>Wishlist (${wishlist.length})</h2>
      ${wishlist.length
        ? html`<div class="grid">${wishlist.map(siteCard)}</div>`
        : html`<p class="empty">Tap "Save" on any monument to keep it here.</p>`}
    </section>`);
}

export const saved = {
  render(el) {
    root = el;
    draw();
  },
  actions: {
    'trip-open'(el) {
      const trip = store.trips().find((t) => t.id === el.dataset.id);
      if (!trip) return;
      store.saveDraft({
        siteIds: trip.siteIds,
        startTime: /^([01]\d|2[0-3]):[0-5]\d$/.test(trip.startTime) ? trip.startTime : '09:00',
        date: trip.date ?? '',
        optimize: false,
        origin: ['none', 'hyderabad'].includes(trip.origin) ? trip.origin : 'none',
      });
      location.hash = '#/builder';
    },
    'trip-delete'(el) {
      store.removeTrip(el.dataset.id);
      toast('Trip deleted');
      draw();
    },
  },
  // Called by main.js on storage changes, only while this view is active.
  refresh: draw,
};
