import { api } from '../lib/api.js';
import { html, mount, toast } from '../lib/dom.js';
import { circuitOf, districtName } from '../lib/catalog.js';
import { duration, hoursText, mapsLink, ticketText } from '../lib/format.js';
import { estimateSeconds, buildNarration, isPlaying, speechSupported, stopNarration, toggleNarration } from '../lib/audio.js';
import { store } from '../lib/store.js';

const dialog = () => document.getElementById('detail');
let currentSite = null;

function fact(label, value) {
  return html`<div><dt>${label}</dt><dd>${value}</dd></div>`;
}

function body(site) {
  const circuit = circuitOf(site);
  const t = site.transit;
  const saved = store.wishlist().includes(site.id);
  const inTrip = store.draft().siteIds.includes(site.id);
  const narration = buildNarration(site);
  return html`
    <div class="dialog-head">
      <button class="btn small secondary dialog-close" data-action="close" aria-label="Close details">Close</button>
      <h2 id="detailTitle">${site.name}</h2>
      <p>${circuit?.name} · ${districtName(site.district)} district · ${site.period}${site.unesco ? ' · UNESCO World Heritage Site' : ''}</p>
    </div>
    <div class="dialog-body">
      <div class="btn-row">
        <button class="btn small secondary" data-action="wish" data-id="${site.id}" aria-pressed="${saved}">${saved ? '♥ Saved' : '♡ Save'}</button>
        <button class="btn small" data-action="add" data-id="${site.id}" ${inTrip ? 'disabled' : ''}>${inTrip ? 'In itinerary' : '+ Itinerary'}</button>
        <a class="btn small secondary" href="${mapsLink(site)}" target="_blank" rel="noopener noreferrer">Open in Maps</a>
        ${speechSupported() && html`<button class="btn small secondary" data-action="listen" data-id="${site.id}" aria-pressed="false">▶ Listen (about ${estimateSeconds(narration)} s)</button>`}
      </div>

      <section><h3>Overview</h3><p>${site.summary}</p><p>${site.history}</p></section>
      <section><h3>Architecture</h3><p>${site.architecture}</p></section>

      <section>
        <h3>Visiting guide</h3>
        <dl class="facts">
          ${fact('Hours', hoursText(site))}
          ${fact('Entry tickets', ticketText(site))}
          ${fact('Typical visit', duration(site.visitMinutes))}
          ${fact('Best time', site.bestTime)}
          ${fact('Dress code', site.dressCode)}
        </dl>
      </section>

      <section>
        <h3>Best photo spots</h3>
        <ul>${site.photoSpots.map((p) => html`<li>${p}</li>`)}</ul>
      </section>

      ${t && html`
      <section>
        <h3>Getting there from Hyderabad</h3>
        <dl class="facts">
          ${fact('Distance and drive', `About ${t.fromHyderabadKm} km, ${t.driveTime}`)}
          ${fact('Nearest railhead', t.railhead)}
          ${fact('TGSRTC bus', t.bus)}
          ${fact('Road conditions', t.road)}
          ${fact('Parking', t.parking)}
          ${fact('Local transport', t.local)}
        </dl>
      </section>`}
      <p class="meta">Hours, prices, transport and coordinates are indicative. Verify before you travel.</p>
    </div>`;
}

export async function openDetail(id) {
  const d = dialog();
  d.className = '';
  mount(d, html`<div class="dialog-body"><p class="loading">Loading…</p></div>`);
  if (!d.open) d.showModal();
  try {
    const site = await api.site(id);
    currentSite = site;
    d.className = `c-${site.circuit}`;
    mount(d, body(site));
    d.scrollTop = 0;
    d.querySelector('.dialog-close')?.focus();
  } catch (err) {
    mount(d, html`<div class="dialog-body"><p class="notice error">${err.message}</p><button class="btn" data-action="close">Close</button></div>`);
  }
}

export function closeDetail() {
  stopNarration();
  if (dialog().open) dialog().close();
}

export function listen(button) {
  if (!currentSite) return;
  const label = () => {
    const playing = isPlaying(currentSite.id);
    button.setAttribute('aria-pressed', String(playing));
    button.textContent = playing ? '■ Stop' : `▶ Listen (about ${estimateSeconds(buildNarration(currentSite))} s)`;
  };
  if (!toggleNarration(currentSite, label)) return toast('Audio is not supported in this browser');
  return label();
}

export function initDetail() {
  const d = dialog();
  d.addEventListener('close', stopNarration);
  // Clicking the backdrop closes the dialog.
  d.addEventListener('click', (e) => { if (e.target === d) closeDetail(); });
}
