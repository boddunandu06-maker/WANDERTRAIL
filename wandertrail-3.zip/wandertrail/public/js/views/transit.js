import { api } from '../lib/api.js';
import { html, mount } from '../lib/dom.js';
import { getCatalog, districtName } from '../lib/catalog.js';

let root = null;
let transitRows = null;

async function loadTransit() {
  if (!transitRows) transitRows = await api.transit();
  return transitRows;
}

function row(t, site) {
  return html`
    <tr>
      <td><button class="btn small secondary" data-action="open" data-id="${site.id}">${site.name}</button><br><span class="meta">${districtName(site.district)}</span></td>
      <td>${t.fromHyderabadKm} km<br><span class="meta">${t.driveTime}</span></td>
      <td>${t.railhead}</td>
      <td>${t.bus}</td>
      <td>${t.road}<br><span class="meta">Parking: ${t.parking}</span></td>
    </tr>`;
}

export const transit = {
  async render(el) {
    root = el;
    mount(el, html`<p class="loading">Loading transport guide…</p>`);
    try {
      const rows = await loadTransit();
      const { siteMap, circuits } = getCatalog();
      const entries = rows.map((t) => ({ t, site: siteMap.get(t.siteId) })).filter((e) => e.site).sort((a, b) => a.t.fromHyderabadKm - b.t.fromHyderabadKm);
      mount(el, html`
        <h1>Getting there from Hyderabad</h1>
        <p>Distances are approximate road distances. Many rural heritage sites have informal transport, so confirm the last leg locally (auto-rickshaw or private taxi fares are negotiable). TGSRTC is the Telangana State Road Transport Corporation, formerly TSRTC.</p>
        <label>Show circuit
          <select id="tCircuit" data-change="transit-filter">
            <option value="">All circuits</option>
            ${circuits.map((c) => html`<option value="${c.id}">${c.name}</option>`)}
          </select>
        </label>
        <div class="table-wrap section">
          <table>
            <thead><tr><th scope="col">Monument</th><th scope="col">From Hyderabad</th><th scope="col">Nearest railhead</th><th scope="col">TGSRTC bus</th><th scope="col">Road and parking</th></tr></thead>
            <tbody id="tBody">${entries.map(({ t, site }) => row(t, site))}</tbody>
          </table>
        </div>`);
      root.dataset.entries = JSON.stringify(entries.map(({ t }) => t.siteId));
    } catch (err) {
      mount(el, html`<p class="notice error">${err.message}</p>`);
    }
  },

  changes: {
    'transit-filter'() {
      const circuit = root.querySelector('#tCircuit').value;
      const { siteMap } = getCatalog();
      const entries = transitRows
        .map((t) => ({ t, site: siteMap.get(t.siteId) }))
        .filter((e) => e.site && (!circuit || e.site.circuit === circuit))
        .sort((a, b) => a.t.fromHyderabadKm - b.t.fromHyderabadKm);
      mount(root.querySelector('#tBody'), html`${entries.map(({ t, site }) => row(t, site))}`);
    },
  },
};
