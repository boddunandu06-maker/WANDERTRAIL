import { html, mount, delegate } from './lib/dom.js';
import { loadCatalog } from './lib/catalog.js';
import { addToDraft, syncButtons, toggleWishlist } from './lib/actions.js';
import { closeDetail, initDetail, listen, openDetail } from './views/detail.js';
import { home } from './views/home.js';
import { explore } from './views/explore.js';
import { builder } from './views/builder.js';
import { saved } from './views/saved.js';
import { transit } from './views/transit.js';
import { passport } from './views/passport.js';
import { safety } from './views/safety.js';
import { trip } from './views/trip.js';

const view = document.getElementById('view');
const nav = document.getElementById('mainNav');
const navToggle = document.getElementById('navToggle');

const routes = { '': home, explore, builder, saved, transit, passport, safety, trip };
const views = Object.values(routes);
let active = home;

/** Handlers shared by every view, merged with each view's own maps. */
const clickHandlers = {
  open: (el) => openDetail(el.dataset.id),
  close: closeDetail,
  wish: (el) => { toggleWishlist(el.dataset.id); },
  add: (el) => { addToDraft(el.dataset.id); },
  listen: (el) => listen(el),
  ...Object.assign({}, ...views.map((v) => v.actions ?? {})),
};
const changeHandlers = Object.assign({}, ...views.map((v) => v.changes ?? {}));
const inputHandlers = Object.assign({}, ...views.map((v) => v.inputs ?? {}));
const dragHandlers = builder.drag;

function bindMap(eventName, attribute, handlers) {
  document.addEventListener(eventName, (event) => {
    const target = event.target.closest(`[${attribute}]`);
    const handler = target && handlers[target.getAttribute(attribute)];
    if (handler) handler(target, event);
  });
}

function parseHash() {
  const [path, query = ''] = location.hash.replace(/^#\/?/, '').split('?');
  const [name = '', arg] = path.split('/');
  return { name, arg, params: new URLSearchParams(query) };
}

async function route() {
  const { name, arg, params } = parseHash();
  const current = routes[name] ?? home;
  const key = routes[name] ? name : '';
  nav.classList.remove('open');
  navToggle.setAttribute('aria-expanded', 'false');
  nav.querySelectorAll('a').forEach((a) => {
    if (a.dataset.route === key) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  active = current;
  await current.render(view, params, arg);
  document.title = `${key ? `${key[0].toUpperCase()}${key.slice(1)} · ` : ''}WanderTrail`;
  syncButtons();
  window.scrollTo({ top: 0 });
  view.focus({ preventScroll: true });
}

async function boot() {
  try {
    await loadCatalog();
  } catch (err) {
    mount(view, html`<p class="notice error">${err.message}</p><button class="btn" data-action="retry">Try again</button>`);
    clickHandlers.retry = () => location.reload();
    return;
  }
  initDetail();
  delegate(document, 'click', clickHandlers);
  bindMap('change', 'data-change', changeHandlers);
  bindMap('input', 'data-input', inputHandlers);
  document.addEventListener('submit', (e) => e.preventDefault());

  // Drag and drop for itinerary stops.
  document.addEventListener('dragstart', (e) => { const li = e.target.closest?.('.stop-item'); if (li) dragHandlers.start(li); });
  document.addEventListener('dragend', (e) => { const li = e.target.closest?.('.stop-item'); if (li) dragHandlers.end(li); });
  document.addEventListener('dragover', (e) => { if (e.target.closest?.('.stop-item')) e.preventDefault(); });
  document.addEventListener('drop', (e) => {
    const li = e.target.closest?.('.stop-item');
    if (li) { e.preventDefault(); dragHandlers.drop(li); }
  });

  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
  window.addEventListener('hashchange', route);
  window.addEventListener('wt:store', () => { syncButtons(); active.refresh?.(); });

  await route();
}

boot();
