import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');

/** Central, immutable configuration. Environment variables override defaults. */
export const config = Object.freeze({
  port: Number.parseInt(process.env.PORT ?? '3000', 10),
  dbPath: process.env.DB_PATH ?? path.join(root, 'data', 'wandertrail.db'),
  publicDir: path.join(root, 'public'),
  seedDir: path.join(here, 'db', 'seed'),
  // Straight-line distance is multiplied by this to estimate road distance.
  roadFactor: 1.3,
  avgSpeedKmh: 45,
  lunchMinutes: 45,
  maxSitesPerPlan: 12,
  maxBodyBytes: '20kb',
  rateLimit: { windowMs: 60_000, max: 120 },
  // Default origin used to pick a sensible first stop when none is supplied.
  hyderabad: Object.freeze({ name: 'Hyderabad', lat: 17.385, lng: 78.4867 }),
});
