import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';

const readSeed = (name, dir = config.seedDir) => JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8'));

const SCHEMA = `
CREATE TABLE IF NOT EXISTS districts (id TEXT PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS circuits (id TEXT PRIMARY KEY, name TEXT NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS heritage_sites (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  circuit_id TEXT NOT NULL REFERENCES circuits(id),
  district_id TEXT NOT NULL REFERENCES districts(id),
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sites_circuit ON heritage_sites(circuit_id);
CREATE INDEX IF NOT EXISTS idx_sites_district ON heritage_sites(district_id);
CREATE TABLE IF NOT EXISTS transit_routes (site_id TEXT PRIMARY KEY REFERENCES heritage_sites(id), data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS itineraries (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  plan TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`;

function matches(site, { circuit, district, q }) {
  if (circuit && site.circuit !== circuit) return false;
  if (district && site.district !== district) return false;
  if (q) {
    const hay = `${site.name} ${site.dynasty} ${site.summary}`.toLowerCase();
    if (!hay.includes(q)) return false;
  }
  return true;
}

/** SQLite-backed repository (Node's built-in node:sqlite). */
class SqliteRepository {
  constructor(db) {
    this.db = db;
    this.kind = 'sqlite';
  }

  static async create(file, seedDir) {
    const { DatabaseSync } = await import('node:sqlite');
    if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
    const db = new DatabaseSync(file);
    db.exec('PRAGMA foreign_keys = ON');
    db.exec(SCHEMA);
    const repo = new SqliteRepository(db);
    repo.seed(seedDir);
    return repo;
  }

  seed(seedDir = config.seedDir) {
    const { count } = this.db.prepare('SELECT COUNT(*) AS count FROM heritage_sites').get();
    if (count > 0) return;
    const districts = readSeed('districts.json', seedDir);
    const circuits = readSeed('circuits.json', seedDir);
    const sites = readSeed('sites.json', seedDir);
    const transit = readSeed('transit.json', seedDir);
    this.db.exec('BEGIN');
    try {
      const insD = this.db.prepare('INSERT INTO districts (id, name) VALUES (?, ?)');
      districts.forEach((d) => insD.run(d.id, d.name));
      const insC = this.db.prepare('INSERT INTO circuits (id, name, data) VALUES (?, ?, ?)');
      circuits.forEach((c) => insC.run(c.id, c.name, JSON.stringify(c)));
      const insS = this.db.prepare('INSERT INTO heritage_sites (id, name, circuit_id, district_id, lat, lng, data) VALUES (?, ?, ?, ?, ?, ?, ?)');
      sites.forEach((s) => insS.run(s.id, s.name, s.circuit, s.district, s.lat, s.lng, JSON.stringify(s)));
      const insT = this.db.prepare('INSERT INTO transit_routes (site_id, data) VALUES (?, ?)');
      transit.forEach((t) => insT.run(t.siteId, JSON.stringify(t)));
      this.db.exec('COMMIT');
    } catch (err) {
      this.db.exec('ROLLBACK');
      throw err;
    }
  }

  listDistricts() {
    const counts = new Map(
      this.db.prepare('SELECT district_id AS id, COUNT(*) AS n FROM heritage_sites GROUP BY district_id').all().map((r) => [r.id, r.n]),
    );
    return this.db.prepare('SELECT id, name FROM districts ORDER BY name').all().map((d) => ({ ...d, siteCount: counts.get(d.id) ?? 0 }));
  }

  listCircuits() {
    const counts = new Map(
      this.db.prepare('SELECT circuit_id AS id, COUNT(*) AS n FROM heritage_sites GROUP BY circuit_id').all().map((r) => [r.id, r.n]),
    );
    return this.db.prepare('SELECT data FROM circuits').all().map((r) => {
      const c = JSON.parse(r.data);
      return { ...c, siteCount: counts.get(c.id) ?? 0 };
    });
  }

  listSites(filter = {}) {
    // Indexed columns narrow the set in SQL; free text is matched in JS.
    const where = [];
    const params = [];
    if (filter.circuit) { where.push('circuit_id = ?'); params.push(filter.circuit); }
    if (filter.district) { where.push('district_id = ?'); params.push(filter.district); }
    const sql = `SELECT data FROM heritage_sites ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY name`;
    return this.db.prepare(sql).all(...params).map((r) => JSON.parse(r.data)).filter((s) => matches(s, { q: filter.q }));
  }

  getSite(id) {
    const row = this.db.prepare('SELECT data FROM heritage_sites WHERE id = ?').get(id);
    return row ? JSON.parse(row.data) : null;
  }

  getSitesByIds(ids) {
    const found = ids.map((id) => this.getSite(id));
    return found.filter(Boolean);
  }

  getTransit(siteId) {
    const row = this.db.prepare('SELECT data FROM transit_routes WHERE site_id = ?').get(siteId);
    return row ? JSON.parse(row.data) : null;
  }

  listTransit() {
    return this.db.prepare('SELECT data FROM transit_routes').all().map((r) => JSON.parse(r.data));
  }

  saveItinerary(title, plan) {
    const id = crypto.randomUUID();
    const createdAt = new Date().toISOString();
    this.db.prepare('INSERT INTO itineraries (id, title, plan, created_at) VALUES (?, ?, ?, ?)').run(id, title, JSON.stringify(plan), createdAt);
    return { id, title, createdAt };
  }

  getItinerary(id) {
    const row = this.db.prepare('SELECT id, title, plan, created_at FROM itineraries WHERE id = ?').get(id);
    return row ? { id: row.id, title: row.title, createdAt: row.created_at, plan: JSON.parse(row.plan) } : null;
  }

  close() {
    this.db.close();
  }
}

/** Fallback used only when node:sqlite is unavailable (Node older than 22.5). */
class JsonRepository {
  constructor(seedDir, file) {
    this.kind = 'json';
    this.districts = readSeed('districts.json', seedDir);
    this.circuits = readSeed('circuits.json', seedDir);
    this.sites = readSeed('sites.json', seedDir);
    this.transit = new Map(readSeed('transit.json', seedDir).map((t) => [t.siteId, t]));
    this.file = file;
    this.itineraries = new Map();
    if (file && fs.existsSync(file)) {
      try {
        JSON.parse(fs.readFileSync(file, 'utf8')).forEach((i) => this.itineraries.set(i.id, i));
      } catch {
        /* ignore a corrupt store and start fresh */
      }
    }
  }

  listDistricts() {
    return this.districts.map((d) => ({ ...d, siteCount: this.sites.filter((s) => s.district === d.id).length }));
  }

  listCircuits() {
    return this.circuits.map((c) => ({ ...c, siteCount: this.sites.filter((s) => s.circuit === c.id).length }));
  }

  listSites(filter = {}) {
    return this.sites.filter((s) => matches(s, filter)).sort((a, b) => a.name.localeCompare(b.name));
  }

  getSite(id) {
    return this.sites.find((s) => s.id === id) ?? null;
  }

  getSitesByIds(ids) {
    return ids.map((id) => this.getSite(id)).filter(Boolean);
  }

  getTransit(siteId) {
    return this.transit.get(siteId) ?? null;
  }

  listTransit() {
    return [...this.transit.values()];
  }

  saveItinerary(title, plan) {
    const id = crypto.randomUUID();
    const record = { id, title, createdAt: new Date().toISOString(), plan };
    this.itineraries.set(id, record);
    if (this.file) {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify([...this.itineraries.values()]));
    }
    return { id, title, createdAt: record.createdAt };
  }

  getItinerary(id) {
    return this.itineraries.get(id) ?? null;
  }

  close() {}
}

/**
 * Open the data tier. Prefers SQLite; falls back to a JSON store when the
 * runtime has no node:sqlite.
 */
export async function createRepository({ dbPath = config.dbPath, seedDir = config.seedDir } = {}) {
  try {
    return await SqliteRepository.create(dbPath, seedDir);
  } catch (err) {
    if (err?.code === 'ERR_UNKNOWN_BUILTIN_MODULE' || err?.code === 'ERR_MODULE_NOT_FOUND') {
      console.warn('node:sqlite unavailable, using the JSON store instead.');
      const file = dbPath === ':memory:' ? null : `${dbPath}.itineraries.json`;
      return new JsonRepository(seedDir, file);
    }
    throw err;
  }
}

export { SqliteRepository, JsonRepository };
