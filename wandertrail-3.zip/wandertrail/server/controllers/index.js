import { notFound } from '../errors.js';
import { planItinerary } from '../services/itinerary.js';
import {
  isSlug,
  validatePlanRequest,
  validateShareId,
  validateSharedItinerary,
  validateSiteQuery,
} from '../services/validation.js';
import { badRequest } from '../errors.js';

const DISCLAIMER =
  'Opening hours, ticket prices, transport details and coordinates are indicative and can change. Verify with the site or the ASI before travelling.';

/**
 * Framework-independent controllers. Each handler takes (req, res) and only
 * uses req.query, req.params, req.body and res.status().json(), so it can be
 * unit-tested without Express.
 */
export function createControllers(repo) {
  function resolveSites(ids) {
    const sites = repo.getSitesByIds(ids);
    if (sites.length !== ids.length) {
      const known = new Set(sites.map((s) => s.id));
      const missing = ids.filter((id) => !known.has(id));
      throw badRequest('Unknown site id(s)', { missing });
    }
    // Keep the caller's order so a manual order can be respected.
    const byId = new Map(sites.map((s) => [s.id, s]));
    return ids.map((id) => byId.get(id));
  }

  return {
    health(_req, res) {
      res.status(200).json({ status: 'ok', store: repo.kind });
    },

    listDistricts(_req, res) {
      res.status(200).json({ data: repo.listDistricts() });
    },

    listCircuits(_req, res) {
      res.status(200).json({ data: repo.listCircuits() });
    },

    listSites(req, res) {
      const filter = validateSiteQuery(req.query);
      const data = repo.listSites(filter);
      res.status(200).json({ count: data.length, data, disclaimer: DISCLAIMER });
    },

    getSite(req, res) {
      if (!isSlug(req.params.id)) throw badRequest('Invalid site id');
      const site = repo.getSite(req.params.id);
      if (!site) throw notFound('Site not found');
      res.status(200).json({ data: { ...site, transit: repo.getTransit(site.id) }, disclaimer: DISCLAIMER });
    },

    listTransit(_req, res) {
      res.status(200).json({ data: repo.listTransit(), disclaimer: DISCLAIMER });
    },

    getTransit(req, res) {
      if (!isSlug(req.params.id)) throw badRequest('Invalid site id');
      const transit = repo.getTransit(req.params.id);
      if (!transit) throw notFound('Transit information not found');
      res.status(200).json({ data: transit, disclaimer: DISCLAIMER });
    },

    planItinerary(req, res) {
      const request = validatePlanRequest(req.body);
      const sites = resolveSites(request.siteIds);
      const plan = planItinerary(sites, request);
      res.status(200).json({ data: plan });
    },

    createItinerary(req, res) {
      const { title, request } = validateSharedItinerary(req.body);
      const plan = planItinerary(resolveSites(request.siteIds), request);
      const saved = repo.saveItinerary(title, { request, plan });
      res.status(201).json({ data: saved });
    },

    getItinerary(req, res) {
      const id = validateShareId(req.params.id);
      const found = repo.getItinerary(id);
      if (!found) throw notFound('Itinerary not found');
      res.status(200).json({ data: found });
    },
  };
}
