import { Router } from 'express';
import { createControllers } from '../controllers/index.js';
import { asyncHandler } from '../middleware/index.js';

export function createApiRouter(repo) {
  const c = createControllers(repo);
  const router = Router();

  router.get('/health', asyncHandler(c.health));
  router.get('/districts', asyncHandler(c.listDistricts));
  router.get('/circuits', asyncHandler(c.listCircuits));
  router.get('/sites', asyncHandler(c.listSites));
  router.get('/sites/:id', asyncHandler(c.getSite));
  router.get('/transit', asyncHandler(c.listTransit));
  router.get('/sites/:id/transit', asyncHandler(c.getTransit));
  router.post('/itineraries/plan', asyncHandler(c.planItinerary));
  router.post('/itineraries', asyncHandler(c.createItinerary));
  router.get('/itineraries/:id', asyncHandler(c.getItinerary));

  return router;
}
