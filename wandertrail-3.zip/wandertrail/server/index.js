import { config } from './config.js';
import { createApp } from './app.js';
import { createRepository } from './db/repository.js';

const repo = await createRepository();
const app = createApp(repo);

const server = app.listen(config.port, () => {
  console.log(`WanderTrail running at http://localhost:${config.port} (store: ${repo.kind})`);
});

function shutdown() {
  server.close(() => {
    repo.close();
    process.exit(0);
  });
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
