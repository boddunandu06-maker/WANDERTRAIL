import express from 'express';
import { config } from './config.js';
import { apiNotFound, errorHandler, rateLimit, securityHeaders } from './middleware/index.js';
import { createApiRouter } from './routes/index.js';

/** Build the Express application. The repository is injected so tests can use an in-memory store. */
export function createApp(repo) {
  const app = express();
  app.disable('x-powered-by');
  app.use(securityHeaders);
  app.use('/api', rateLimit(config.rateLimit));
  app.use('/api', express.json({ limit: config.maxBodyBytes }));
  app.use('/api', createApiRouter(repo));
  app.use('/api', apiNotFound);
  app.use(express.static(config.publicDir, { maxAge: '1h', index: 'index.html' }));
  app.use(errorHandler);
  return app;
}
