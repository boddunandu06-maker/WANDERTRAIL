import { config } from '../config.js';
import { badRequest } from '../errors.js';

const SLUG = /^[a-z0-9-]{1,60}$/;
const TIME = /^([01]\d|2[0-3]):([0-5]\d)$/;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const CONTROL = /[\u0000-\u001f\u007f<>]/g;

/** Strip control characters and angle brackets, trim and cap length. */
export function cleanText(value, max = 80) {
  if (typeof value !== 'string') return '';
  return value.replace(CONTROL, '').trim().slice(0, max);
}

export function isSlug(value) {
  return typeof value === 'string' && SLUG.test(value);
}

function isRealDate(str) {
  if (!DATE.test(str)) return false;
  const d = new Date(`${str}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === str;
}

/** Validate the query string of GET /api/sites. */
export function validateSiteQuery(query = {}) {
  const out = {};
  for (const key of ['circuit', 'district']) {
    if (query[key] !== undefined && query[key] !== '') {
      if (!isSlug(query[key])) throw badRequest(`Invalid ${key}`);
      out[key] = query[key];
    }
  }
  if (query.q !== undefined && query.q !== '') {
    if (typeof query.q !== 'string') throw badRequest('Invalid search text');
    out.q = cleanText(query.q, 60).toLowerCase();
  }
  return out;
}

function validateOrigin(origin) {
  if (origin === undefined || origin === null) return null;
  const { lat, lng } = origin;
  if (typeof lat !== 'number' || typeof lng !== 'number' || !Number.isFinite(lat) || !Number.isFinite(lng)) {
    throw badRequest('origin.lat and origin.lng must be numbers');
  }
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) throw badRequest('origin is out of range');
  return { name: cleanText(origin.name ?? 'Origin', 40) || 'Origin', lat, lng };
}

/** Validate the body of POST /api/itineraries/plan. */
export function validatePlanRequest(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw badRequest('Request body must be a JSON object');
  const { siteIds, startTime = '09:00', date, optimize = true } = body;

  if (!Array.isArray(siteIds) || siteIds.length === 0) throw badRequest('siteIds must be a non-empty array');
  if (siteIds.length > config.maxSitesPerPlan) throw badRequest(`A plan can include at most ${config.maxSitesPerPlan} sites`);
  if (!siteIds.every(isSlug)) throw badRequest('siteIds contains an invalid id');
  if (new Set(siteIds).size !== siteIds.length) throw badRequest('siteIds must not contain duplicates');

  if (typeof startTime !== 'string' || !TIME.test(startTime)) throw badRequest('startTime must be HH:MM (24 hour)');
  if (date !== undefined && date !== null && date !== '' && !(typeof date === 'string' && isRealDate(date))) {
    throw badRequest('date must be a real date in YYYY-MM-DD format');
  }
  if (typeof optimize !== 'boolean') throw badRequest('optimize must be true or false');

  return {
    siteIds,
    startTime,
    date: date || undefined,
    optimize,
    origin: validateOrigin(body.origin),
  };
}

/** Validate the body of POST /api/itineraries (share a plan). */
export function validateSharedItinerary(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw badRequest('Request body must be a JSON object');
  const title = cleanText(body.title ?? '', 80);
  if (!title) throw badRequest('title is required');
  const request = validatePlanRequest(body.plan ?? {});
  return { title, request };
}

export function validateShareId(id) {
  if (typeof id !== 'string' || !/^[0-9a-f-]{36}$/.test(id)) throw badRequest('Invalid itinerary id');
  return id;
}
