const EARTH_RADIUS_KM = 6371.0088;
const toRad = (deg) => (deg * Math.PI) / 180;

/**
 * Great-circle distance between two {lat, lng} points in kilometres (Haversine).
 * @param {{lat:number,lng:number}} a
 * @param {{lat:number,lng:number}} b
 * @returns {number}
 */
export function haversineKm(a, b) {
  for (const p of [a, b]) {
    if (!p || !Number.isFinite(p.lat) || !Number.isFinite(p.lng)) {
      throw new TypeError('haversineKm expects points with numeric lat and lng');
    }
  }
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Estimated road distance: straight-line distance scaled by a winding factor. */
export function roadKm(a, b, factor = 1.3) {
  return haversineKm(a, b) * factor;
}

export const round1 = (n) => Math.round(n * 10) / 10;
