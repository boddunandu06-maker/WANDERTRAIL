import { config } from '../config.js';
import { roadKm, round1 } from './geo.js';

const HHMM = /^([01]\d|2[0-3]):([0-5]\d)$/;

export function toMinutes(hhmm) {
  const m = HHMM.exec(hhmm);
  if (!m) throw new TypeError(`Invalid time "${hhmm}", expected HH:MM`);
  return Number(m[1]) * 60 + Number(m[2]);
}

export function toHHMM(minutes) {
  const m = Math.max(0, Math.round(minutes));
  const h = Math.floor(m / 60) % 24;
  return `${String(h).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
}

/** Sum of road distances along an ordered path (origin optional). */
export function pathLengthKm(path, origin, factor = config.roadFactor) {
  let total = 0;
  let prev = origin ?? null;
  for (const site of path) {
    if (prev) total += roadKm(prev, site, factor);
    prev = site;
  }
  return total;
}

/**
 * Greedy nearest-neighbour sequencing.
 * Starts from `start` and repeatedly hops to the closest unvisited site.
 * Ties are broken by id so output is deterministic.
 */
export function greedySequence(sites, start, factor = config.roadFactor) {
  const remaining = sites.filter((s) => s.id !== start.id);
  const order = [start];
  let current = start;
  while (remaining.length) {
    let bestIdx = 0;
    let bestDist = Infinity;
    remaining.forEach((candidate, i) => {
      const d = roadKm(current, candidate, factor);
      if (d < bestDist - 1e-9 || (Math.abs(d - bestDist) <= 1e-9 && candidate.id < remaining[bestIdx].id)) {
        bestDist = d;
        bestIdx = i;
      }
    });
    current = remaining.splice(bestIdx, 1)[0];
    order.push(current);
  }
  return order;
}

/**
 * 2-opt refinement of an open path. Keeps the first stop fixed so the
 * chosen starting point (or origin leg) is respected.
 */
export function twoOpt(order, origin, factor = config.roadFactor) {
  const best = order.slice();
  let bestLen = pathLengthKm(best, origin, factor);
  let improved = true;
  while (improved) {
    improved = false;
    for (let i = 1; i < best.length - 1; i += 1) {
      for (let j = i + 1; j < best.length; j += 1) {
        const candidate = best.slice(0, i).concat(best.slice(i, j + 1).reverse(), best.slice(j + 1));
        const len = pathLengthKm(candidate, origin, factor);
        if (len < bestLen - 1e-9) {
          best.splice(0, best.length, ...candidate);
          bestLen = len;
          improved = true;
        }
      }
    }
  }
  return best;
}

/**
 * Choose the first stop. With an origin, it is the closest site to it.
 * Without one, the path begins at whichever end of the widest pair of
 * sites is nearer Hyderabad, so trips fan outward along the highway.
 */
export function chooseStart(sites, origin, factor = config.roadFactor) {
  if (origin) {
    return sites.reduce((a, b) => (roadKm(origin, b, factor) < roadKm(origin, a, factor) ? b : a));
  }
  if (sites.length === 1) return sites[0];
  let pair = [sites[0], sites[1]];
  let widest = -1;
  for (let i = 0; i < sites.length; i += 1) {
    for (let j = i + 1; j < sites.length; j += 1) {
      const d = roadKm(sites[i], sites[j], factor);
      if (d > widest) {
        widest = d;
        pair = [sites[i], sites[j]];
      }
    }
  }
  const hyd = config.hyderabad;
  return roadKm(hyd, pair[0], factor) <= roadKm(hyd, pair[1], factor) ? pair[0] : pair[1];
}

/**
 * Build the timed schedule for an ordered list of stops.
 * Adds a lunch break, waits for opening time and flags closures.
 */
export function buildSchedule(order, { origin, startTime = '09:00', date, factor = config.roadFactor } = {}) {
  const warnings = [];
  const stops = [];
  const legs = [];
  let clock = toMinutes(startTime);
  let prev = origin ?? null;
  let lunchTaken = false;
  const weekday = date ? new Date(`${date}T00:00:00Z`).getUTCDay() : null;

  order.forEach((site, index) => {
    let legKm = 0;
    let legMin = 0;
    if (prev) {
      legKm = roadKm(prev, site, factor);
      legMin = (legKm / config.avgSpeedKmh) * 60;
      clock += legMin;
    }
    legs.push({ from: prev ? (prev.name ?? prev.id) : null, to: site.name, km: round1(legKm), minutes: Math.round(legMin) });

    if (!lunchTaken && clock >= 12 * 60 + 30 && index > 0) {
      clock += config.lunchMinutes;
      lunchTaken = true;
    }

    const opens = toMinutes(site.hours.open);
    const closes = toMinutes(site.hours.close);
    let waited = 0;
    if (clock < opens) {
      waited = opens - clock;
      clock = opens;
      warnings.push(`${site.name} opens at ${site.hours.open}; allow about ${Math.round(waited)} minutes of waiting or start later.`);
    }
    const arrive = clock;
    const depart = arrive + site.visitMinutes;
    if (depart > closes) {
      warnings.push(`${site.name} closes at ${site.hours.close}; your planned visit ends at ${toHHMM(depart)}. Start earlier or drop a stop.`);
    }
    if (weekday !== null && site.hours.closedDays?.includes(weekday)) {
      warnings.push(`${site.name} is normally closed on this weekday. Pick another day.`);
    }
    stops.push({
      order: index + 1,
      id: site.id,
      name: site.name,
      district: site.district,
      lat: site.lat,
      lng: site.lng,
      arrive: toHHMM(arrive),
      depart: toHHMM(depart),
      visitMinutes: site.visitMinutes,
      legKm: round1(legKm),
      legMinutes: Math.round(legMin),
    });
    clock = depart;
    prev = site;
  });

  return { stops, legs, warnings, endTime: toHHMM(clock) };
}

/**
 * Plan a day trip.
 * @param {object[]} sites  Full site records.
 * @param {{origin?:object, startTime?:string, date?:string, optimize?:boolean}} opts
 */
export function planItinerary(sites, opts = {}) {
  if (!Array.isArray(sites) || sites.length === 0) throw new TypeError('At least one site is required');
  const { origin = null, startTime = '09:00', date, optimize = true } = opts;
  const factor = config.roadFactor;

  let order = sites.slice();
  if (optimize) {
    order = greedySequence(sites, chooseStart(sites, origin, factor), factor);
    if (order.length > 3) order = twoOpt(order, origin, factor);
  }

  const schedule = buildSchedule(order, { origin, startTime, date, factor });
  const totalKm = round1(pathLengthKm(order, origin, factor));
  const driveMinutes = schedule.stops.reduce((sum, s) => sum + s.legMinutes, 0);
  return {
    algorithm: optimize ? 'greedy-nearest-neighbour+2-opt' : 'user-defined-order',
    origin: origin ? { name: origin.name ?? 'Origin', lat: origin.lat, lng: origin.lng } : null,
    startTime,
    date: date ?? null,
    totalKm,
    driveMinutes,
    endTime: schedule.endTime,
    stops: schedule.stops,
    legs: schedule.legs,
    warnings: schedule.warnings,
    note: 'Distances are estimated road distances (straight line x 1.3). Check live conditions before you travel.',
  };
}
